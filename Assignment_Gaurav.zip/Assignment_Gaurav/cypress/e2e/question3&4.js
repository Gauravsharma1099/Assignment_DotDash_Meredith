//cypress code
//testcase is a spec file
describe('Assignment Question 3 & 4', function(){

    it("Question 3 & 4", function(){
    
    cy.visit("https://www.foodandwine.com/featured/original/unforgettable-dinner-party-barilla-2023/")
    //cy.get('div[id="FloatingImage-13"] a').click()
    cy.get('div[id="FloatingImage-27"] a').click()
    })
    
    })