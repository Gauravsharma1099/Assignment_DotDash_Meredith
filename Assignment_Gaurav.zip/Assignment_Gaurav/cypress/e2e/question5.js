//cypress code
//testcase is a spec file
describe('Assignment Question 5', function(){

    
    it("Question 5", function(){
    
        cy.visit("https://www.verywellhealth.com/")
        //cy.get('div[id="FloatingImage-13"] a').click()
       cy.get('#mntl-card-list-items_1-0').click();
       cy.contains("Tejocote Root Weight Loss Supplements May Contain Toxic Substance, FDA Warns")
        })
    
    })