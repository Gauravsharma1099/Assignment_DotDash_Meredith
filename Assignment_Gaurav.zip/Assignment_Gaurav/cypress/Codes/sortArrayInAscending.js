function sortArrayAscending(arr)
{
    return arr.sort((a,b) => a - b);
}

console.log(sortArrayAscending([10,1,20,2,5]))