function countVowels(str)
{
    const vowels = ["a", "e", "i", "o", "u"];
    var count = 0;

    //Iterate through each character in the string

    for(let char of str.toLowerCase())
    {
        // check if the character is the vowel
        if(vowels.includes(char))
        {
            count++;
        }

    }

return count;


}

// to call a function
console.log(countVowels("Hello World"));